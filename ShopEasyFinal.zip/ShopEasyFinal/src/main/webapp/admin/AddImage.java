package project;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/AddImage")
@MultipartConfig
public class AddImage extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public AddImage() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Part file = request.getPart("images");

        // Get the image file name
        String imageFileName = file.getSubmittedFileName();
        String uploadPath = getServletContext().getRealPath("/images") + "/" + imageFileName;

        try (InputStream input = file.getInputStream();
                FileOutputStream output = new FileOutputStream(uploadPath)) {
            // Copy the uploaded image to the destination path
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Save image file information to the database
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping", "root","Akshu1308@.");
            String query = "INSERT INTO images (imageFileName) VALUES (?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, imageFileName);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Image added into the database successfully.");
            } else {
                System.out.println("Failed to upload image.");
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("addImage.jsp");
    }
}
