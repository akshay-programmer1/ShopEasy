package project;

public @interface WebServlet {

}
