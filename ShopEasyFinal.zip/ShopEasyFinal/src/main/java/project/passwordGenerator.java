package project;
import java.util.Random;
public class passwordGenerator {

	    public static String generateNewPassword() {
	        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	        StringBuilder newPassword = new StringBuilder();
	        int length = 25; // Set the desired length of the password

	        Random random = new Random();
	        for (int i = 0; i < length; i++) {
	            int index = random.nextInt(characters.length());
	            newPassword.append(characters.charAt(index));
	        }

	        return newPassword.toString();
	    }
	}
