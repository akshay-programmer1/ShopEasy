package project;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/Product")
public class AddProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        double price = Double.parseDouble(request.getParameter("price"));
        String status = request.getParameter("status");
        
        // Handle image upload
        Part imagePart = request.getPart("image_url");
        String imageName = imagePart.getSubmittedFileName();
        String imageUrl = "images/" + imageName; // Update with your actual image storage path
        String imagePath = getServletContext().getRealPath("/") + imageUrl;
        imagePart.write(imagePath);

        // Create a new Product object
        Product newProduct = new Product(name, category, price, status, imageUrl);

        // Call the ProductDao to add the product to the database
        ProductDao productDao = new ProductDao();
        productDao.addProduct(newProduct);

        // Redirect to a confirmation page or display a success message
        response.sendRedirect("productDetails.jsp?name=" + name + "&category=" + category + "&price=" + price + "&status=" + status + "&image_url=" + imageUrl);

    }
}
