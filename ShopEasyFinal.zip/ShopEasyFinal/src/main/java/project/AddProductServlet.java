package project;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

@WebServlet("/addProductServlet")
@MultipartConfig
public class AddProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        double price = Double.parseDouble(request.getParameter("price"));
        String status = request.getParameter("status");
        String imageUrl = null;

        // Directory where you want to store the images
        String uploadPath = "C:\\Users\\ADMIN\\OneDrive\\Desktop\\ShopEasyFinal\\src\\main\\webapp\\Images";

        // Retrieve the uploaded file
        Part filePart = request.getPart("image_url");
        String fileName = UUID.randomUUID().toString() + "_" + filePart.getSubmittedFileName();
        
        // Set the imageUrl to the relative path of the uploaded image
        imageUrl = "Images/" + fileName;

        // Define the file path where the image will be stored
        File uploadedFile = new File(uploadPath, fileName);

        // Save the image to the specified directory
     // ...

     // Save the image to the specified directory
     try (InputStream input = filePart.getInputStream()) {
         Files.copy(input, uploadedFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
     } catch (IOException e) {
         // Handle the exception
     }

     // ...


        // Now you have all the form data, including the image path (imageUrl)
        // You can save this data to your database or perform other operations as needed.
    }
}
