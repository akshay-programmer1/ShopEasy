package project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DisplayServlet")
public class DisplayServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DisplayServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String imageId = request.getParameter("imageId");
        int id = Integer.parseInt(imageId);

        int imgId = 0;
        String imgFileName = null;

        // Getting database connection (jdbc code)
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping", "root",
                "Akshu1308@.")) {
            String query = "SELECT * FROM image WHERE imageId = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, id);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        imgId = rs.getInt("imageId");
                        imgFileName = rs.getString("imageFileName");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        RequestDispatcher rd;
        request.setAttribute("id", String.valueOf(imgId));
        request.setAttribute("img", imgFileName);
        rd = request.getRequestDispatcher("displayImage.jsp");
        rd.forward(request, response);
    }
}
